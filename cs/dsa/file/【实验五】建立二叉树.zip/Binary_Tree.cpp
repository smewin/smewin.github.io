#include<iostream>
#include<string>
#include <cassert>
#define zyf FW
using namespace std;
typedef struct Node{
    char flag;
    struct Node *left;
    struct Node *right;
    int data;
    Node(char flag){
        this->flag=flag;
        this->left=NULL;
        this->right=NULL;
        this->data=0;
    }
}Binary_Tree_Node;
Binary_Tree_Node *root=NULL;
string io_temp;
void create_tree(Binary_Tree_Node *node){
    //Something once happens
}
Binary_Tree_Node* tree_search(Binary_Tree_Node *node, char flag){
    if(node == NULL){
        return NULL;
    }else if(node->flag == flag){
        return node;
    }else{
        Binary_Tree_Node *temp=tree_search(node->left, flag);
        if(temp!=NULL){
            return temp;
        }else{
            return tree_search(node->right, flag);
        }
    }
}
void tree_insert(Binary_Tree_Node *node, char flag, int loc){
    switch (loc){
    case 1:
        node->left=new Binary_Tree_Node(flag);
        break;
    case 0:
        node->right=new Binary_Tree_Node(flag);
        break;
    default:
        assert(0);
        break;
    }
}
void pre_order(Binary_Tree_Node *node){
    if(node == NULL){
        return;
    }
    cout << node->flag ;
    pre_order(node->left);
    pre_order(node->right);
}
void in_order(Binary_Tree_Node *node){
    if(node == NULL){
        return;
    }
    in_order(node->left);
    cout << node->flag ;
    in_order(node->right);
}
void post_order(Binary_Tree_Node *node){
    if(node == NULL){
        return;
    }
    post_order(node->left);
    post_order(node->right);
    cout << node->flag ;
}
int main(){
    while(1){
        cin >> io_temp;
        if(io_temp.length()!=3){
            assert(0);
        }else{
            if(io_temp[1]=='^') break;
            if(io_temp[0]=='^'){
                root=new Binary_Tree_Node(io_temp[1]);
            }else{
                if(io_temp[2]=='L'){
                    tree_insert(tree_search(root,io_temp[0]),io_temp[1],0x1);
                }else{
                    tree_insert(tree_search(root,io_temp[0]),io_temp[1],0x0);
                }
            }
        }
    }
    cout << "-----------------------------------------------" << endl << "Preorder: ";
    pre_order(root);
    cout << endl << "Inoredr: ";
    in_order(root);
    cout << endl << "Postorder: ";
    post_order(root);
    cout << endl;
    cout << "-----------------------------------------------" << endl;
    return 0;
}