#include<iostream>
#define Past_Dream FW
using namespace std;
#define Max 998244353
struct Stack_Node{
    int x , y , op;
    Stack_Node *next;
    Stack_Node(int _x=0,int _y=0){
        x=_x;
        y=_y;
        op = 0;
        next=NULL;
    }
};
class My_Stack{
    Stack_Node *top;
public:
    void Stack_Init();
    void Stack_Push(Stack_Node *p);
    Stack_Node* Stack_Pop();
    Stack_Node* Stack_Top();
    bool Stack_Empty();
    void Stack_Clear();
    void Stack_Destroy();
};
void My_Stack::Stack_Init(){
    top=NULL;
}
void My_Stack::Stack_Push(Stack_Node *p){
    p->next=top;
    top=p;
}
Stack_Node* My_Stack::Stack_Pop(){
    Stack_Node *p=top;
    top=top->next;
    return p;
}
Stack_Node* My_Stack::Stack_Top(){
    return top;
}
bool My_Stack::Stack_Empty(){
    return (top==NULL);
}
void My_Stack::Stack_Clear(){
    while(top!=NULL){
        Stack_Pop();
    }
}
void My_Stack::Stack_Destroy(){
    while(top!=NULL){
        Stack_Node *p=top;
        top=top->next;
        delete p;
    }
}
Stack_Node *nil = new Stack_Node(0,0);
Stack_Node* Next_Node_op(Stack_Node *p, Stack_Node *Now, Stack_Node *Dead){
    Stack_Node *next = new Stack_Node(Now->x, Now->y);
    if(Dead == nil){
        if(p == nil){
            next->x = Now->x - 1;
            next->y = Now->y;
            return next;
        }
        if(Now->x == p->x+1 && Now->y == p->y){
            next->x = Now->x;
            next->y = Now->y+1;
            Now->op = 1;
            return next;
        }
        else if(Now->x == p->x-1 && Now->y == p->y){
            next->x = Now->x;
            next->y = Now->y-1;
            Now->op = 3;
            return next;
        }
        else if(Now->x == p->x && Now->y == p->y+1){
            next->x = Now->x-1;
            next->y = Now->y;
            Now->op = 4;
            return next;
        }
        else if(Now->x == p->x && Now->y == p->y-1){
            next->x = Now->x+1;
            next->y = Now->y;
            Now->op = 2;
            return next;
        }
    }else{
        if(Dead->x == Now->x+1 && Dead->y == Now->y){
            next->x = Now->x;
            next->y = Now->y-1;
            Now->op = 3;
            if(next->x != p->x || next->y != p->y) return next;
            else return nil;
        }
        else if(Dead->x == Now->x-1 && Dead->y == Now->y){
            next->x = Now->x;
            next->y = Now->y+1;
            Now->op = 1;
            if(next->x != p->x || next->y != p->y) return next;
            else return nil;
        }
        else if(Dead->x == Now->x && Dead->y == Now->y+1){
            next->x = Now->x+1;
            next->y = Now->y;
            Now->op = 2;
            if(next->x != p->x || next->y != p->y) return next;
            else return nil;
        }
        else if(Dead->x == Now->x && Dead->y == Now->y-1){
            next->x = Now->x-1;
            next->y = Now->y;
            Now->op = 4;
            if(next->x != p->x || next->y != p->y) return next;
            else return nil;
        }
    }
    return nil;
}
int main(){
    int n , m, start_x, start_y, end_x, end_y;
    cout << "Please enter the number of rows and columns of the maze:";
    cin >> n >> m ;
    int a[n+1][m+1];
    char g_ans[n+1][m+1];
    cout << "Please enter the maze layout (0 means passable, 1 means obstacle):" << endl;
    for(int i = 1 ;i <= n ; i++ ){
        for(int j = 1 ; j <= m ; j++ ){
            cin >> a[i][j];
            g_ans[i][j] = a[i][j] +48 ;
        }
    }
    cout << "Please enter the starting and ending coordinates (x y):" << endl;
    cin >> start_x >> start_y >> end_x >> end_y;
    cout << "------------------Ans------------------" << endl;
    if(a[start_x][start_y] == 1 || a[end_x][end_y] == 1 || start_x > n || start_x < 1 || start_y > m || start_y < 1 || end_x > n || end_x < 1 || end_y > m || end_y < 1){
        cout << "No" << endl;
        cout << "---------------------------------------" << endl;
        return 0;
    }
    My_Stack s , ans;
    s.Stack_Init();
    ans.Stack_Init();
    Stack_Node *p = new Stack_Node(start_x-1, start_y);
    Stack_Node *Now = new Stack_Node(start_x, start_y);
    Stack_Node *Dead = nil;
    Stack_Node *next = nil;
    Stack_Node *temp_p_Start = p;
    p=nil;
    s.Stack_Push(Now);
    while(!s.Stack_Empty()){
        Now = (s.Stack_Top());
        if(Now->x == end_x && Now->y == end_y){
            cout << "Yes" << endl;
            cout << "---------------------------------------" << endl;
            break;
        }
        next = Next_Node_op(p, Now, Dead);
        if(next == nil){
            Dead = s.Stack_Pop();
            if(!s.Stack_Empty())Now = s.Stack_Pop();
            else break;
            if(!s.Stack_Empty())p = s.Stack_Top();
            else p = temp_p_Start;
            s.Stack_Push(Now);   
        }else{
            if(a[next->x][next->y] == 0 && next->x > 0 && next->x < n+1 && next->y > 0 && next->y < m+1 && (next->x != p->x || next->y != p->y)){
                p = Now;
                s.Stack_Push(next);
                Now = next;
                Dead = nil;
            }else{
                Dead = next;
            }
        }
    }
    if(s.Stack_Empty()){
        cout << "No" << endl;
        cout << "---------------------------------------" << endl;
    }else{
        Stack_Node *temp ;
        while(!s.Stack_Empty()){        
            temp = s.Stack_Pop();
            ans.Stack_Push(temp);
            /*
            if((temp->op & 0x1 && g_ans[temp->x][temp->y] == 124) || ((!temp->op & 0x1) && g_ans[temp->x][temp->y] == 95)) g_ans[temp->x][temp->y] = 43;
            else if(temp->op & 0x1) g_ans[temp->x][temp->y] = 95;
            else g_ans[temp->x][temp->y] = 124;
            */
            g_ans[temp->x][temp->y] = 43;
        }
        while(!ans.Stack_Empty()){
            Stack_Node t = *(ans.Stack_Top());
            cout << "(" << t.x << ", " << t.y << ", " << t.op << ")";
            ans.Stack_Pop();
        }
        cout << endl;
        cout << "---------------------------------------" << endl;
        for(int i = 1 ; i <= n ; i++){
            for(int j = 1 ; j <= m ; j++){
                cout << g_ans[i][j] << " ";
            }
            cout << endl;
        }
        cout << "---------------------------------------" << endl;
    }
    s.Stack_Destroy();
    ans.Stack_Destroy();
    return 0;
}