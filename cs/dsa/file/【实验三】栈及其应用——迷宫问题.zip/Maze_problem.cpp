#include<iostream>
#define Past_Dream FW
using namespace std;
#define Max 998244353
int main()
{
    int m , n , p_temp , p_t_temp , dtemp;
    cout << "Please enter the number of rows and columns of the maze:";
    cin >> m >> n;
    int a[m+2][n+2],d[m+2][n+2][2],temp[m*n][2],t_temp[m*n][2];
    cout << "Please enter the maze layout (0 means passable, 1 means obstacle):" << endl;
    for(int i = 1 ; i <= m ; i++)
    {
        for(int j = 1 ; j <= n ; j++)
        {
            cin >> a[i][j];
            d[i][j][0] = Max;
            d[i][j][1] = 0;
        }
    }
    int x1 , y1 , x2 , y2;
    cout << "Please enter the starting and ending coordinates (x y):" << endl;
    cin >> x1 >> y1 >> x2 >> y2;
    cout << "------------------Ans------------------" << endl;
    p_temp = 1;
    temp[1][0] = x1 , temp[1][1] = y1;
    d[x1][y1][0] = 0; 
    if(a[x2][y2] == 1){
        cout << "No" << endl;
        return 0;
    }
    while(p_temp != 0 && d[x2][y2][0] >= Max){
        p_t_temp = 1;
        for(int i = 1 ; i <= p_temp ; i++){
            if(temp[i][0] != 1 && a[temp[i][0]-1][temp[i][1]]!=1){
                dtemp = d[temp[i][0]][temp[i][1]][0] + 1;
                if(dtemp < d[temp[i][0]-1][temp[i][1]][0]){
                    d[temp[i][0]-1][temp[i][1]][0] = dtemp;
                    d[temp[i][0]-1][temp[i][1]][1] = 4;
                    t_temp[p_t_temp][0] = temp[i][0]-1;
                    t_temp[p_t_temp][1] = temp[i][1];
                    p_t_temp++;
                }
            }
            if(temp[i][0] != m && a[temp[i][0]+1][temp[i][1]]!=1){
                dtemp = d[temp[i][0]][temp[i][1]][0] + 1;
                if(dtemp < d[temp[i][0]+1][temp[i][1]][0]){
                    d[temp[i][0]+1][temp[i][1]][0] = dtemp;
                    d[temp[i][0]+1][temp[i][1]][1] = 2;
                    t_temp[p_t_temp][0] = temp[i][0]+1;
                    t_temp[p_t_temp][1] = temp[i][1];
                    p_t_temp++;
                }
            }
            if(temp[i][1] != 1 && a[temp[i][0]][temp[i][1]-1]!=1){
                dtemp = d[temp[i][0]][temp[i][1]][0] + 1;
                if(dtemp < d[temp[i][0]][temp[i][1]-1][0]){
                    d[temp[i][0]][temp[i][1]-1][0] = dtemp;
                    d[temp[i][0]][temp[i][1]-1][1] = 3;
                    t_temp[p_t_temp][0] = temp[i][0];
                    t_temp[p_t_temp][1] = temp[i][1]-1;
                    p_t_temp++;
                }
            }
            if(temp[i][1] != n && a[temp[i][0]][temp[i][1]+1]!=1){
                dtemp = d[temp[i][0]][temp[i][1]][0] + 1;
                if(dtemp < d[temp[i][0]][temp[i][1]+1][0]){
                    d[temp[i][0]][temp[i][1]+1][0] = dtemp;
                    d[temp[i][0]][temp[i][1]+1][1] = 1;
                    t_temp[p_t_temp][0] = temp[i][0];
                    t_temp[p_t_temp][1] = temp[i][1]+1;
                    p_t_temp++;
                }
            }
        }
        p_temp = p_t_temp - 1;
        for(int i = 1 ; i <= p_temp ; i++){
            temp[i][0] = t_temp[i][0];
            temp[i][1] = t_temp[i][1];
        }
    }
    if(d[x2][y2][0] == Max){
        cout << "No" << endl;
        cout << "---------------------------------------" << endl;
    }else{
        cout << "Yes" << endl;
        cout << "---------------------------------------" << endl;
        for(int i = 1 ; i <= m ; i++){
            for(int j = 1 ; j <= n ; j++){
                if(d[i][j][0] == Max){
                    cout << "- ";
                }
                else cout << d[i][j][0] << " ";
            }
            cout << endl;
        }
        cout << "---------------------------------------" << endl;
        int x = x2 , y = y2;
        p_temp = 1;
        temp[p_temp][0] = x;
        temp[p_temp][1] = y;
        temp[0][0] = 0;
        temp[0][1] = 0;
        a[x][y] = 8;
        p_temp++;
        while(x!=x1 || y!=y1){
            switch(d[x][y][1]){
                case 1:
                    y--;
                    break;
                case 2:
                    x--;
                    break;
                case 3:
                    y++;
                    break;
                case 4:
                    x++;
                    break;
                default:
                    break;    
            }
            temp[p_temp][0] = x;
            temp[p_temp][1] = y;
            a[x][y] = 8;
            p_temp ++;
        }
        d[0][0][1] = 0;
        cout << "The shortest path is:" << endl;
        for(int i = p_temp-1 ; i >= 1 ; i--){
            cout << "(" << temp[i][0] << ", " << temp[i][1] << " ," << d[temp[i-1][0]][temp[i-1][1]][1] << ")" ;
        }
        cout << endl;
        cout << "The length of the shortest path is: " << d[x2][y2][0] << endl;
        cout << "---------------------------------------" << endl;
        for(int i = 1 ; i <= m ; i++){
            for(int j = 1 ; j <= n ; j++){
                cout << a[i][j] << " ";
            }
            cout << endl;
        }
        cout << "---------------------------------------" << endl;
    }
    return 0;
}