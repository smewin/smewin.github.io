#include <iostream>
#include <string>
#define zyf FW
using namespace std;
const int MAXN = 100;
struct Node{
    int data;
    int row,col;       //结点所在行列
    Node* nextInRow;   //同行中下一个结点
    Node* nextInColumn;//同列中下一个结点
    Node(int data, int row, int col): data(data),row(row),col(col),nextInRow(nullptr),nextInColumn(nullptr){}
};
class MATRIX;
struct mul_output{
    MATRIX *m;
    int cnt;
};
class MATRIX{
    struct Node* columns[MAXN];   //对应于每一列的单链表，每个单链表中行号递增
    struct Node* rows[MAXN];      //对应于每一行的单链表，每个单链表中列号递增
    struct Node* columns_tail[MAXN];
    struct Node* rows_tail[MAXN];
    int rowN,colN;                //行数和列数
public:
    MATRIX(int m, int n): rowN(m), colN(n){
        for(int i = 0; i < MAXN; i++){
            columns[i] = nullptr;
            rows[i] = nullptr;
            columns_tail[i] = nullptr;
            rows_tail[i] = nullptr;
        }
    }
    void insert(int data, int row, int col);
    mul_output* multiple(MATRIX * m1, MATRIX *m2);//m1的列数等于m2的行数
    mul_output* add(MATRIX * m1, MATRIX *m2);
    mul_output* sub(MATRIX * m1, MATRIX *m2);
    mul_output* transpose(MATRIX * m1);
    void print_MATRIX(MATRIX *m);
    void print_MATRIX2(MATRIX *m);
};
void MATRIX::insert(int data, int row, int col){
    Node *p = new Node(data, row, col);
    if(rows[row] == nullptr){
        rows[row] = p;
        rows_tail[row] = p;
    }
    else{
        rows_tail[row]->nextInRow = p;
        rows_tail[row] = p;
    }
    if(columns[col] == nullptr){
        columns[col] = p;
        columns_tail[col] = p;
    }
    else{
        columns_tail[col]->nextInColumn = p;
        columns_tail[col] = p;
    }
    return ;
}
mul_output* MATRIX::multiple(MATRIX *m1, MATRIX *m2){
    MATRIX *m3 = new MATRIX(m1->rowN, m2->colN);
    int cnt_m3 = 0;
    mul_output *mo = new mul_output;
    for(int i = 1; i <= m1->rowN; i++){
        if(!(m1 -> rows[i])) continue;
        for(int j = 1; j <= m2->colN; j++){
            if(!(m2->columns[j])) continue;
            int sum = 0;
            Node *p = m1->rows[i];
            Node *q = m2->columns[j];
            while(p && q){
                if(p->col == q->row){
                    sum += p->data * q->data;
                    p = p->nextInRow;
                    q = q->nextInColumn;
                }
                else if(p->col < q->row){
                    p = p->nextInRow;
                }
                else{
                    q = q->nextInColumn;
                }
            }
            if(sum != 0){
                m3->insert(sum, i, j);
                cnt_m3++;
            }
        }
    }
    mo->m = m3;
    mo->cnt = cnt_m3;
    return mo;
}
mul_output* MATRIX::add(MATRIX * m1, MATRIX *m2){
    MATRIX *m3 = new MATRIX(m1->rowN, m1->colN);
    int cnt_m3 = 0;
    mul_output *mo = new mul_output;
    // 遍历第一矩阵的非零元素
    for(int i = 1; i <= m1->rowN; i++){
        Node *p = m1->rows[i];
        Node *q = m2->rows[i];
        while(p || q){
            if(p && (!q || p->col < q->col)){
                // m1 有非零元素，m2 没有或 m1 的列号小于 m2 的列号
                m3->insert(p->data, p->row, p->col);
                cnt_m3++;
                p = p->nextInRow;
            } else if(q && (!p || q->col < p->col)){
                // m2 有非零元素，m1 没有或 m2 的列号小于 m1 的列号
                m3->insert(q->data, q->row, q->col);
                cnt_m3++;
                q = q->nextInRow;
            } else {
                // 两个矩阵在同一个位置都有非零元素
                int sum = p->data + q->data;
                if(sum != 0){
                    m3->insert(sum, p->row, p->col);
                    cnt_m3++;
                }
                p = p->nextInRow;
                q = q->nextInRow;
            }
        }
    }
    mo->m = m3;
    mo->cnt = cnt_m3;
    return mo;
}
mul_output* MATRIX::sub(MATRIX * m1, MATRIX *m2){
    MATRIX *m3 = new MATRIX(m1->rowN, m1->colN);
    int cnt_m3 = 0;
    mul_output *mo = new mul_output;
    // 遍历第一矩阵的非零元素
    for(int i = 1; i <= m1->rowN; i++){
        Node *p = m1->rows[i];
        Node *q = m2->rows[i];
        while(p || q){
            if(p && (!q || p->col < q->col)){
                // m1 有非零元素，m2 没有或 m1 的列号小于 m2 的列号
                m3->insert(p->data, p->row, p->col);
                cnt_m3++;
                p = p->nextInRow;
            } else if(q && (!p || q->col < p->col)){
                // m2 有非零元素，m1 没有或 m2 的列号小于 m1 的列号
                m3->insert(-q->data, q->row, q->col); // 注意这里是负值
                cnt_m3++;
                q = q->nextInRow;
            } else {
                // 两个矩阵在同一个位置都有非零元素
                int diff = p->data - q->data;
                if(diff != 0){
                    m3->insert(diff, p->row, p->col);
                    cnt_m3++;
                }
                p = p->nextInRow;
                q = q->nextInRow;
            }
        }
    }

    mo->m = m3;
    mo->cnt = cnt_m3;
    return mo;
}
mul_output* MATRIX::transpose(MATRIX * m1){
    MATRIX *m3 = new MATRIX(m1->colN, m1->rowN);
    int cnt_m3 = 0;
    mul_output *mo = new mul_output;
    for(int i = 1; i <= m1->colN; i++){
        if(!(m1 -> columns[i])) continue;
        for(int j = 1; j <= m1->rowN; j++){
            if(!(m1->rows[j])) continue;
            Node *p = m1->columns[i];
            while(p){
                if(p->row == j){
                    m3->insert(p->data, i, j);
                    cnt_m3++;
                    break;
                }
                p = p->nextInColumn;
            }
        }
    }
    mo->m = m3;
    mo->cnt = cnt_m3;
    return mo;
}
void MATRIX::print_MATRIX(MATRIX *m){
    for(int i = 0; i <= m->rowN; i++){
        Node *p = m->rows[i];
        while(p){
            printf("%d %d %d\n", p->row, p->col, p->data);
            p = p->nextInRow;
        }
    }
}
void MATRIX::print_MATRIX2(MATRIX *m) {
    int matrix[MAXN][MAXN] = {0};
    for (int i = 1; i <= m->rowN; i++) {
        Node *p = m->rows[i];
        while (p) {
            matrix[p->row][p->col] = p->data;
            p = p->nextInRow;
        }
    }
    for (int i = 1; i <= m->rowN; i++) {
        for (int j = 1; j <= m->colN; j++) {
            cout << matrix[i][j] << " ";
        }
        cout << endl;
    }
}
int main(){
    int p , q , r , t , cnt , data_temp , row_temp , column_temp;
    string opcode;
    MATRIX *m1, *m2, *m3;
    mul_output *mo;
    cout << "Hello world! This is a sparse matrix operator." << endl;
    while(1){
        cout << "--------------------------------------------------" << endl;
    
        cout << "If you want to perform sparse matrix addition, please enter 1 (or a or add); If you want to perform sparse matrix subtraction, please enter 2 (or s or sub); If you want to perform sparse matrix multiplication, please enter 3 (or m or mul); If you want to perform sparse matrix transposition, please enter 4 (or t or tsp); If you want to exit, please enter 0(or q or exit)." << endl;
        cout << "Please enter the operation code:";
        cin >> opcode;
        if(opcode == "1"||opcode == "a"||opcode == "add"){
            cout << "Please enter the dimensions of the first matrix (rows, columns):" ;
            scanf("%d %d", &p, &q);
            m1 = new MATRIX(p, q);
            cout << "Please enter the number of non-zero elements:";
            scanf("%d", &cnt);
            cout << "Please enter the non-zero elements in the format (row, column, data):" << endl;
            for(int i = 0; i < cnt; i++){
                scanf("%d %d %d", &row_temp, &column_temp, &data_temp);
                m1->insert(data_temp, row_temp, column_temp);
            }
            cout << "Please enter the dimensions of the second matrix (rows, columns):" ;
            scanf("%d %d", &r, &t);
            m2 = new MATRIX(r, t);
            cout << "Please enter the number of non-zero elements:";
            scanf("%d", &cnt);
            cout << "Please enter the non-zero elements in the format (row, column, data):" << endl;
            for(int i = 0; i < cnt; i++){
                scanf("%d %d %d", &row_temp, &column_temp, &data_temp);
                m2->insert(data_temp, row_temp, column_temp);
            }
            if(p != r || q != t){
                cout << "The dimensions of the two matrices are not the same!" << endl;
                delete m1;
                delete m2;
                continue;
            }
            m3 = new MATRIX(p, q);
            mo = m3->add(m1, m2);
            m3 = mo->m;
            cout << "The sum of the two matrices is:" << endl;
            printf("%d\n", mo->cnt);
            m3->print_MATRIX(m3);
            cout << "---------------------------------" << endl;
            m3->print_MATRIX2(m3);
            delete m1;
            delete m2;
            delete m3;
            delete mo;
            continue;
        }else if(opcode == "2"||opcode == "s"||opcode == "sub"){
            cout << "Please enter the dimensions of the first matrix (rows, columns):" ;
            scanf("%d %d", &p, &q);
            m1 = new MATRIX(p, q);
            cout << "Please enter the number of non-zero elements:";
            scanf("%d", &cnt);
            cout << "Please enter the non-zero elements in the format (row, column, data):" << endl;
            for(int i = 0; i < cnt; i++){
                scanf("%d %d %d", &row_temp, &column_temp, &data_temp);
                m1->insert(data_temp, row_temp, column_temp);
            }
            cout << "Please enter the dimensions of the second matrix (rows, columns):" ;
            scanf("%d %d", &r, &t);
            m2 = new MATRIX(r, t);
            cout << "Please enter the number of non-zero elements:";
            scanf("%d", &cnt);
            cout << "Please enter the non-zero elements in the format (row, column, data):" << endl;
            for(int i = 0; i < cnt; i++){
                scanf("%d %d %d", &row_temp, &column_temp, &data_temp);
                m2->insert(data_temp, row_temp, column_temp);
            }
            if(p != r || q != t){
                cout << "The dimensions of the two matrices are not the same!" << endl;
                delete m1;
                delete m2;
                continue;
            }
            m3 = new MATRIX(p, q);
            mo = m3->sub(m1, m2);
            m3 = mo->m;
            cout << "The difference of the two matrices is:" << endl;
            printf("%d\n", mo->cnt);
            m3->print_MATRIX(m3);
            cout << "---------------------------------" << endl;
            m3->print_MATRIX2(m3);
            delete m1;
            delete m2;
            delete m3;
            delete mo;
            continue;
        }else if(opcode == "3"||opcode == "m"||opcode == "mul"){
            cout << "Please enter the dimensions of the first matrix (rows, columns):" ;
            scanf("%d %d", &p, &q);
            m1 = new MATRIX(p, q);
            cout << "Please enter the number of non-zero elements:";
            scanf("%d", &cnt);
            cout << "Please enter the non-zero elements in the format (row, column, data):" << endl;
            for(int i = 0; i < cnt; i++){
                scanf("%d %d %d", &row_temp, &column_temp, &data_temp);
                m1->insert(data_temp, row_temp, column_temp);
            }
            cout << "Please enter the dimensions of the second matrix (rows, columns):" ;
            scanf("%d %d", &r, &t);
            m2 = new MATRIX(r, t);
            cout << "Please enter the number of non-zero elements:";
            scanf("%d", &cnt);
            for(int i = 0; i < cnt; i++){
                scanf("%d %d %d", &row_temp, &column_temp, &data_temp);
                m2->insert(data_temp, row_temp, column_temp);
            }
            if(q != r){
                cout << "The dimensions of the two matrices are not compatible for multiplication!" << endl;
                delete m1;
                delete m2;
                continue;
            }
            m3 = new MATRIX(p, t);
            mo = m3->multiple(m1, m2);
            m3 = mo->m;
            cout << "The product of the two matrices is:" << endl;
            printf("%d\n", mo->cnt);
            m3->print_MATRIX(m3);
            cout << "---------------------------------" << endl;
            m3->print_MATRIX2(m3);
            delete m1;
            delete m2;
            delete m3;
            delete mo;
            continue;
        }else if(opcode == "4"||opcode == "t"||opcode == "tsp"){
            cout << "Please enter the dimensions of the matrix (rows, columns):" ;
            scanf("%d %d", &p, &q);
            m1 = new MATRIX(p, q);
            cout << "Please enter the number of non-zero elements:" ;
            scanf("%d", &cnt);
            cout << "Please enter the non-zero elements in the format (row, column, data):" << endl;
            for(int i = 0; i < cnt; i++){
                scanf("%d %d %d", &row_temp, &column_temp, &data_temp);
                m1->insert(data_temp, row_temp, column_temp);
            }
            m3 = new MATRIX(q, p);
            mo = m3->transpose(m1);
            m3 = mo->m;
            cout << "The transposed matrix is:" << endl;
            printf("%d\n", mo->cnt);
            m3->print_MATRIX(m3);
            cout << "---------------------------------" << endl;
            m3->print_MATRIX2(m3);
            delete m1;
            delete m3;
            delete mo;
            continue;
        }else if(opcode == "0"||opcode == "q"||opcode == "exit"||opcode == "quit"){
            cout << "Thank you for using this sparse matrix operator. Bye!" << endl;
            return 0;
        }else{
            cout << "Invalid operation code!" << endl;
            continue;   
        }
    }    
    return 0;
}