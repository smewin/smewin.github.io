#include<iostream>
#include<cstring>
#include<cstdlib>
#define Past_Dream super_FW
using namespace std;
typedef struct record{
    int event_num;
    int competitor_rank;
    string competitor_name;
    int competitor_score;
}state_record;
int main(){
    int school_num , boys_event_num , girls_event_num;
    cout << "Please enter the number of participating schools:";
    cin >> school_num;
    cout << "Please enter the number of events for boys:";
    cin >> boys_event_num;
    cout << "Please enter the number of events for girls:";
    cin >> girls_event_num;
    int total_event_num = boys_event_num + girls_event_num;
    state_record report_card[school_num+1][6*total_event_num];
    int p[school_num+1] = {0} , boys_score[school_num+1][2] , girls_score[school_num+1][2] , total_score[school_num+1][2] ;
    for(int i = 1 ; i <= school_num ; i++){
        p[i] = 1;
        boys_score[i][0] = 0;
        boys_score[i][1] = i;
        girls_score[i][0] = 0;
        girls_score[i][1] = i;
        total_score[i][0] = 0;
        total_score[i][1] = i;
    }
    int temp_event_num , temp_type , temp_sch , new_rule_temp;
    int new_rule[1000] = {0};
    string temp_name;
    char input_temp[1024];
    for(int i = 1 ; i <= total_event_num ; i++){
        cout << "Please enter the event number:";
        cin >> temp_event_num;
        cout << "Please enter the event type(1 for classical Top 5 scoring competition, 2 for classical Top 3 scoring competition, 3 for new rule):";
        cin >> temp_type;
        switch (temp_type){
            case 1:
                for(int j = 1 ; j <= 5 ; j++){
                    cout << "Please enter the school number of the rank " << j << " competitor:";
                    cin >> temp_sch;
                    cout << "Please enter the name of the rank " << j << " competitor:";
                    cin >> temp_name;
                    report_card[temp_sch][p[temp_sch]].event_num = temp_event_num;
                    report_card[temp_sch][p[temp_sch]].competitor_name = temp_name;
                    report_card[temp_sch][p[temp_sch]].competitor_rank = j;
                    switch(j){
                        case 1:
                            report_card[temp_sch][p[temp_sch]].competitor_score = 7;
                            total_score[temp_sch][0] += 7;
                            if(temp_event_num <= boys_event_num) boys_score[temp_sch][0] += 7;
                            else girls_score[temp_sch][0] += 7;
                            break;
                        case 2:
                            report_card[temp_sch][p[temp_sch]].competitor_score = 5;
                            total_score[temp_sch][0] += 5;
                            if(temp_event_num <= boys_event_num) boys_score[temp_sch][0] += 5;
                            else girls_score[temp_sch][0] += 5;
                            break;
                        case 3:
                            report_card[temp_sch][p[temp_sch]].competitor_score = 3;
                            total_score[temp_sch][0] += 3;
                            if(temp_event_num <= boys_event_num) boys_score[temp_sch][0] += 3;
                            else girls_score[temp_sch][0] += 3;
                            break;
                        case 4:
                            report_card[temp_sch][p[temp_sch]].competitor_score = 2;
                            total_score[temp_sch][0] += 2;
                            if(temp_event_num <= boys_event_num) boys_score[temp_sch][0] += 2;
                            else girls_score[temp_sch][0] += 2;
                            break;
                        case 5:
                            report_card[temp_sch][p[temp_sch]].competitor_score = 1;
                            total_score[temp_sch][0] += 1;
                            if(temp_event_num <= boys_event_num) boys_score[temp_sch][0] += 1;
                            else girls_score[temp_sch][0] += 1;
                            break;
                        default:
                            cout << "Error, Please contact the administrator." << endl;
                            break;
                    }
                    p[temp_sch]++;
                }
                break;
            case 2:
                for(int j = 1 ; j <= 3 ; j++){
                    cout << "Please enter the school number of the rank " << j << " competitor:";
                    cin >> temp_sch;
                    cout << "Please enter the name of the rank " << j << " competitor:";
                    cin >> temp_name;
                    report_card[temp_sch][p[temp_sch]].event_num = temp_event_num;
                    report_card[temp_sch][p[temp_sch]].competitor_name = temp_name;
                    report_card[temp_sch][p[temp_sch]].competitor_rank = j;
                    switch(j){
                        case 1:
                            report_card[temp_sch][p[temp_sch]].competitor_score = 5;
                            total_score[temp_sch][0] += 5;
                            if(temp_event_num <= boys_event_num) boys_score[temp_sch][0] += 5;
                            else girls_score[temp_sch][0] += 5;
                            break;
                        case 2:
                            report_card[temp_sch][p[temp_sch]].competitor_score = 3;
                            total_score[temp_sch][0] += 3;
                            if(temp_event_num <= boys_event_num) boys_score[temp_sch][0] += 3;
                            else girls_score[temp_sch][0] += 3;
                            break;
                        case 3:
                            report_card[temp_sch][p[temp_sch]].competitor_score = 2;
                            total_score[temp_sch][0] += 2;
                            if(temp_event_num <= boys_event_num) boys_score[temp_sch][0] += 2;
                            else girls_score[temp_sch][0] += 2;
                            break;
                        default:
                            cout << "Error, Please contact the administrator." << endl;
                            break;
                    }
                    p[temp_sch]++;
                }
                break;
            case 3:
                cout << "Please enter how many of the top places can score in this competition:" ;
                cin >> new_rule_temp;
                cout << "Please enter the scores for each position in order of ranking.You can separate the two scores with spaces or carriage returns:";
                for(int j = 1 ; j <= new_rule_temp ; j++){
                    cin >> new_rule[j];
                    if(j!= 1 && new_rule[j] > new_rule[j-1]){
                        fgets(input_temp, sizeof(input_temp), stdin);
                        cout << "Are you sure your input is correct? If you confirm, please enter to skip, otherwise, please enter any character and press enter to re-enter this group of data from the first place.";
                        if (fgets(input_temp, sizeof(input_temp), stdin)) {
                            if (input_temp[0] != '\n'){
                                j = 0;
                                cout << "Please enter the scores for each position in order of ranking.You can separate the two scores with spaces or carriage returns:";
                            }    
                        }
                    }
                }
                for(int j = 1 ; j <= new_rule_temp ; j++){
                    cout << "Please enter the school number of the rank " << j << " competitor:";
                    cin >> temp_sch;
                    cout << "Please enter the name of the rank " << j << " competitor:";
                    cin >> temp_name;
                    report_card[temp_sch][p[temp_sch]].event_num = temp_event_num;
                    report_card[temp_sch][p[temp_sch]].competitor_name = temp_name;
                    report_card[temp_sch][p[temp_sch]].competitor_rank = j;
                    report_card[temp_sch][p[temp_sch]].competitor_score = new_rule[j];
                    total_score[temp_sch][0] += new_rule[j];
                    if(temp_event_num <= boys_event_num) boys_score[temp_sch][0] += new_rule[j];
                    else girls_score[temp_sch][0] += new_rule[j];
                    p[temp_sch]++;
                }
                break;
            default:
                cout << "Error, Please check the input." << endl;
                break;
        }
    }
    for(int i = 1 ; i <= school_num ; i++){
        cout << "School " << i << ":\n";
        cout << "Boys team score: " << boys_score[i][0] << "\n";
        cout << "Girls team score: " << girls_score[i][0] << "\n";
        cout << "Total score: " << total_score[i][0] << "\n";
        for(int j = 1 ; j < p[i] ; j++){
            cout << "Event " << report_card[i][j].event_num << " " << report_card[i][j].competitor_name << " " << report_card[i][j].competitor_rank << " " << report_card[i][j].competitor_score << "\n";
        }
        cout << "--------------------------------------------------------" << endl;
    }
    for(int i = 1 ; i <= school_num ; i++){
        for(int j = i + 1 ; j <= school_num ; j++){
            if(boys_score[i][0] < boys_score[j][0]){
                swap(boys_score[i][0], boys_score[j][0]);
                swap(boys_score[i][1], boys_score[j][1]);
            }
            if(girls_score[i][0] < girls_score[j][0]){
                swap(girls_score[i][0], girls_score[j][0]);
                swap(girls_score[i][1], girls_score[j][1]);
            }
            if(total_score[i][0] < total_score[j][0]){
                swap(total_score[i][0], total_score[j][0]);
                swap(total_score[i][1], total_score[j][1]);
            }
        }
    }
    cout << "Boys' ranking:" << endl;
    for(int i = 1 ; i <= school_num ; i++){
        cout << "School " << boys_score[i][1] << " Boys Team: " << boys_score[i][0] << "\n";
    }
    cout << "--------------------------------------------------------" << endl;
    cout << "Girls' ranking:" << endl;
    for(int i = 1 ; i <= school_num ; i++){
        cout << "School " << girls_score[i][1] << " Girls Team: " << girls_score[i][0] << "\n";
    }
    cout << "--------------------------------------------------------" << endl;
    cout << "Total ranking:" << endl;
    for(int i = 1 ; i <= school_num ; i++){
        cout << "School " << total_score[i][1] << " Total: " << total_score[i][0] << "\n";
    }
    cout << "--------------------------------------------------------" << endl;
    return 0;
}